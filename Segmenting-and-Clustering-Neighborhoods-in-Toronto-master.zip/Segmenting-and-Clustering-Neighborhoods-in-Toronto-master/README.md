# Segmenting-and-Clustering-Neighborhoods-in-Toronto
Segmenting and Clustering Neighborhoods in Toronto_IBM Data Science Capstone Project_Week 3
